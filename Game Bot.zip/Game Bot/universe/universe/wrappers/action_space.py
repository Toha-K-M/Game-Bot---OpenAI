class SoftmaxClickMouse():
    def init(self):
        raise DeprecationWarning('DEPRECATION WARNING: wrappers.SoftmaxClickMouse has been moved to wrappers.experimental.action_space.SoftmaxClickMouse as of 2017-02-08.')


class SafeActionSpace():
    def init(self):
        raise DeprecationWarning('DEPRECATION WARNING: wrappers.SafeActionSpace has been moved to '
                     'wrappers.experimental.action_space.SafeActionSpace as of 2017-01-07. '
                     'Using legacy wrappers.SafeActionSpace will soon be removed')
