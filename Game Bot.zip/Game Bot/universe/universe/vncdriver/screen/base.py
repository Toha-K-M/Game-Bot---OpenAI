import logging
import time

logger = logging.getLogger(__name__)

class Screen(object):
    pass
